from django.shortcuts import render
from .models import *
from django.http import HttpResponse
from datetime import datetime
from django.db import connection
# Create your views here.
def index(request):
    user=request.session.get('userid')
    ct=""
    if user:
        ct=mcart.objects.all().filter(userid=user).count()
        #request.session['cart']=ct
    x=category.objects.all().order_by('-id')[0:12]
    pdata=myproduct.objects.all().order_by('-id')[0:15]
    Slide=slider.objects.all().order_by('-id')[0:2]
    mydict={"data":x,"prodata":pdata,"cart":ct,"slide":Slide}
    return render(request,'user/index.html',mydict)

#######################################

def about(request):
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return render(request,'user/about.html',{'cart':ct})

#######################################

def product(request):
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return render(request,'user/product.html',{'cart':ct})

#######################################

def myorder(request):

    user = request.session.get('userid')
    Oid=request.GET.get('oid')

    ct = ""
    md={}
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    ############################
    if user:
        if Oid is not None:
            morder.objects.all().filter(id=Oid).delete()
            return HttpResponse("<script>alert('Your order has been cancled...');location.href='/user/myorder/'</script>")
        cursor=connection.cursor()
        cursor.execute("select p.*,o.* from user_myproduct p,user_morder o where p.id=o.pid and o.userid='"+str(user)+"' and o.remark='pending'")
        pdata=cursor.fetchall()
        cursor.execute("select p.*,o.* from user_myproduct p,user_morder o where p.id=o.pid and o.userid='" + str(user) + "' and o.remark='Delivered'")
        ddata = cursor.fetchall()
        md={'cart':ct,"pdata":pdata,"ddata":ddata}
    return render(request,'user/myorder.html',md)

#######################################

def enquiry(request):
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    status = False
    if request.method=="POST":
        a=request.POST.get('name')
        b=request.POST.get('email')
        c=request.POST.get('mob')
        d=request.POST.get('msg')
       # mdict={"Name":a,"Email":b,"Mobile":c,"Message":d}
        contactus(Name=a,Email=b,Mobile=c,Message=d).save()
        status=True

    return render(request,'user/inquiry.html',context={"msg":status,'cart':ct})

#######################################

def signup(request):
    if request.method=="POST":
        Name=request.POST.get('name')
        Mobile=request.POST.get('mob')
        Ppic=request.FILES.get('pic')
        Passwd=request.POST.get('pwd')
        Email=request.POST.get('email')
        Address=request.POST.get('add')
        x=register.objects.all().filter(email=Email).count()
        if x==0:
            register(name=Name, email=Email, ppic=Ppic, mobile=Mobile, passwd=Passwd, address=Address).save()
            return HttpResponse("<script>alert('You are Registered Seccussfully');location.href=('/user/signup/')</script>")
        else:
            return HttpResponse("<script>alert('You are Already Registered ');location.href=('/user/signup/')</script>")
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return render(request,'user/signup.html',{'cart':ct})

#######################################

def myprofile(request):
    user = request.session.get('userid')
    x=" "
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    if user:
        if request.method=="POST":
            Name = request.POST.get('name')
            Mobile = request.POST.get('mob')
            Ppic = request.FILES.get('pic')
            Passwd = request.POST.get('pwd')
            Email = request.POST.get('email')
            Address = request.POST.get('add')
            register(email=user,name=Name,mobile=Mobile,ppic=Ppic,passwd=Passwd,address=Address).save()
            return HttpResponse("<script>alert('Your Profile Updated Successfully...');location.href='/user/myprofile/'</script>")
        x=register.objects.all().filter(email=user)


    return render(request,'user/myprofile.html',{'cart':ct,"mdata":x})

#######################################

def signin(request):
    if request.method=="POST":
        Email=request.POST.get('email')
        Passwd=request.POST.get('passwd')
        x=register.objects.all().filter(email=Email,passwd=Passwd).count()
        y=register.objects.all().filter(email=Email,passwd=Passwd)
        if x==1:
            request.session["userid"]=Email
            request.session["userpic"]=str(y[0].ppic)
            return HttpResponse("<script>alert('Your are Logined..');location.href='/user/index/'</script>")
        else:
            return HttpResponse("<script>alert('Your UserId or Password is Incorrect.');location.href=('/user/signin/')</script>")
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return render(request,'user/signin.html',{'cart':ct})

#######################################

def mens(request):
    cid=request.GET.get('msg')
    cat=category.objects.all().order_by('-id')
    d=myproduct.objects.all().order_by("-id").filter(mcategory=1)
    if cid is not None:
        d = myproduct.objects.all().order_by('-id').filter(mcategory=1, pcotegory=cid)
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    mydict={"cats":cat,"data":d,"cart":ct}
    return render(request,'user/mens.html',mydict)

#######################################

def womens(request):
    cid = request.GET.get('msg')
    cat = category.objects.all().order_by('-id')

    d = myproduct.objects.all().order_by("-id").filter(mcategory=2)
    if cid is not None:
        d = myproduct.objects.all().order_by('-id').filter(mcategory=2, pcotegory=cid)
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    mydict = {"cats": cat, "data": d,"cart":ct}
    return render(request,'user/womens.html',mydict)

#######################################


def kids(request):
    cid = request.GET.get('msg')
    cat = category.objects.all().order_by('-id')

    d = myproduct.objects.all().order_by("-id").filter(mcategory=3)
    if cid is not None:
        d = myproduct.objects.all().order_by('-id').filter(mcategory=3, pcotegory=cid)
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    mydict = {"cats": cat, "data": d,"cart":ct}
    return render(request,'user/kids.html',mydict)

##########################################
def viewproduct(request):
    a = request.GET.get('abc')
    if a is not None:
        x=myproduct.objects.all().filter(id=a)
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return render(request,'user/viewproduct.html',{"pdata":x,"cart":ct})

def signout(request):
    if request.session.get('userid'):
        del request.session['userid']
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return HttpResponse("<script>alert('Your are Signed Out..');location.href='/user/index/'</script>")




def myordr(request):
    user=request.session.get('userid')
    Pid = request.GET.get("msg")
    if user:
        if Pid is not None:
            morder(userid=user,pid=Pid,remark="pending",odate=datetime.now().date(),status=True).save()
            return HttpResponse("<script>alert('Your order confirmed...');location.href='/user/index/'</script>")

    else:
        return HttpResponse("<script>alert('You have to login first...');location.href='/user/signin/'</script>")
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return render(request,'myordr.html',{'cart':ct})

def mycart(request):
    p=request.GET.get('pid')
    user=request.session.get('userid')
    if user:
        if p is not None:
            mcart(userid=user,pid=p,cdate=datetime.now().date(),status=True).save()
            return HttpResponse("<script>alert('Your Item is added Cart...');location.href='/user/index/'</script>")
    else:
        return HttpResponse("<script>alert('You Have Login First...');loaction.href='/user/signin/'</script>")
    user = request.session.get('userid')
    ct = ""
    if user:
        ct = mcart.objects.all().filter(userid=user).count()
    return render(request,'user/mycart.html',{'cart':ct})

def showcart(request):
    user=request.session.get('userid')
    md={}
    a=request.GET.get("msg")
    cid=request.GET.get("cid")
    pid=request.GET.get("pid")
    if user:
        if a is not  None:
            mcart.objects.all().filter(id=a).delete()
            return HttpResponse("<script>alert('Your Item is Deleted From Cart...');location.href='/user/showcart/'</script>")
        elif pid is not None:
            mcart.objects.all().filter(id=cid).delete()
            morder(userid=user,pid=pid,remark="panding",status=True,odate=datetime.now().date()).save()
            return HttpResponse("<script>alert('Your Order Has Been Placed Successfully ');location.href='/user/showcart/'</script>")
        cursor=connection.cursor()
        cursor.execute("select p.*,c.* from user_myproduct p,user_mcart c where p.id=c.pid and c.userid='"+str(user)+"'")
        cdata=cursor.fetchall()
        md={"cdata":cdata}
    return render(request,'user/showcart.html',md)


def cpdetail(request):
    p=""
    p = myproduct.objects.all().order_by('-id')
    cid = request.GET.get('cid')
    if cid is not None:
        p = myproduct.objects.all().order_by('-id').filter(pcotegory=cid)
    return render(request,'user/cpdetail.html',{"pdata":p})



